<?php include('config/conexion.php'); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Alumnos</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h1>👥 Registro de Alumnos</h1>

<nav>
    <a href="index.php">Inicio</a>
    <a href="libros.php">Libros</a>
    <a href="prestamos.php">Préstamos</a>
</nav>

<section>
    <h2>Agregar Alumno</h2>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre completo" required>
        <input type="text" name="grado" placeholder="Grado" required>
        <button type="submit" name="registrar">Registrar</button>
    </form>

<?php
if (isset($_POST['registrar'])) {
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $grado  = mysqli_real_escape_string($conn, $_POST['grado']);

    if(mysqli_query($conn, "INSERT INTO alumnos (nombre, grado) VALUES ('$nombre','$grado')")){
        echo "<p class='ok'>Alumno registrado</p>";
    }
}
?>
</section>

<section>
<h2>Lista de Alumnos</h2>
<table>
<tr><th>ID</th><th>Nombre</th><th>Grado</th></tr>

<?php
$res = mysqli_query($conn, "SELECT * FROM alumnos");
while($a = mysqli_fetch_assoc($res)){
    echo "<tr>
            <td>{$a['id_alumno']}</td>
            <td>{$a['nombre']}</td>
            <td>{$a['grado']}</td>
          </tr>";
}
?>
</table>
</section>

</body>
</html>
