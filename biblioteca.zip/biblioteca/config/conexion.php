<?php
$conn = mysqli_connect("localhost", "root", "", "biblioteca_marta");

if (!$conn) {
    die("❌ Error de conexión: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");
?>
