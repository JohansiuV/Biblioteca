<?php
include('config/conexion.php');

$id_p = $_GET['id_p'];
$id_l = $_GET['id_l'];

mysqli_query($conn, "UPDATE prestamos SET estado='devuelto' WHERE id_prestamo=$id_p");
mysqli_query($conn, "UPDATE libros SET stock=stock+1 WHERE id_libro=$id_l");

header("Location: index.php");
