<?php include('config/conexion.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca de Marta - Inicio</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>📚 Panel de Control - Sra. Marta</h1>
    
<nav>
    <a href="index.php">Inicio</a> | 
    <a href="libros.php">Inventario de Libros</a> | 
    <a href="alumnos.php">Registro de Alumnos</a> | 
    <a href="prestamos.php">Registrar Préstamo</a>
</nav>


    <section>
        <h2>⚠️ Libros Pendientes de Devolución</h2>
<table border="1">
    <tr>
        <th>Alumno</th>
        <th>Libro</th>
        <th>Cantidad</th>
        <th>Estado</th>
        <th>Acción</th>
    </tr>

<?php
$res = mysqli_query($conn, "
    SELECT 
        a.nombre, 
        l.titulo, 
        p.cantidad,
        p.id_prestamo, 
        p.id_libro 
    FROM prestamos p
    JOIN alumnos a ON p.id_alumno = a.id_alumno
    JOIN libros l ON p.id_libro = l.id_libro
    WHERE p.estado = 'activo'
");

if (mysqli_num_rows($res) > 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>
                <td>{$row['nombre']}</td>
                <td>{$row['titulo']}</td>
                <td>{$row['cantidad']}</td>
                <td class='alerta'>⚠️ Pendiente</td>
                <td>
                    <a href='devolver.php?id_p={$row['id_prestamo']}&id_l={$row['id_libro']}' class='btn'>
                        Marcar Devuelto
                    </a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No hay deudas pendientes. ¡Marta está al día!</td></tr>";
}
?>
</table>

    </section>

</body>
</html>