<?php 
include('config/conexion.php');

$mensaje = "";

// Procesar préstamo
if (isset($_POST['prestar'])) {

    $id_libro  = (int) $_POST['id_libro'];
    $id_alumno = (int) $_POST['id_alumno'];

    // Verificar stock
    $consulta = mysqli_query($conn, "SELECT stock FROM libros WHERE id_libro = $id_libro");

    if ($consulta && mysqli_num_rows($consulta) > 0) {
        $libro = mysqli_fetch_assoc($consulta);

        if ($libro['stock'] > 0) {

            // Registrar préstamo
            $sql = "INSERT INTO prestamos (id_libro, id_alumno, fecha_salida, estado)
                    VALUES ($id_libro, $id_alumno, CURDATE(), 'activo')";

            if (mysqli_query($conn, $sql)) {

                // Actualizar stock
                mysqli_query($conn, "UPDATE libros SET stock = stock - 1 WHERE id_libro = $id_libro");

                $mensaje = "<p class='ok'>✅ Préstamo registrado correctamente.</p>";
            } else {
                $mensaje = "<p class='error'>❌ Error al registrar el préstamo.</p>";
            }

        } else {
            $mensaje = "<p class='error'>❌ Este libro ya no tiene stock disponible.</p>";
        }
    } else {
        $mensaje = "<p class='error'>❌ Libro no encontrado.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Préstamo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h1>📖 Registrar Préstamo</h1>

<nav>
    <a href="index.php">Inicio</a>
    <a href="libros.php">Libros</a>
    <a href="alumnos.php">Alumnos</a>
</nav>

<section>
    <h2>Formulario de Préstamo</h2>

    <?php echo $mensaje; ?>

    <form method="POST">
        <label>Libro disponible</label>
        <select name="id_libro" required>
            <option value="">-- Selecciona un libro --</option>
            <?php
            $libros = mysqli_query($conn, "SELECT id_libro, titulo, stock FROM libros WHERE stock > 0 ORDER BY titulo");
            while ($l = mysqli_fetch_assoc($libros)) {
                echo "<option value='{$l['id_libro']}'>{$l['titulo']} ({$l['stock']} disponibles)</option>";
            }
            ?>
        </select>

        <label>Alumno</label>
        <select name="id_alumno" required>
            <option value="">-- Selecciona un alumno --</option>
            <?php
            $alumnos = mysqli_query($conn, "SELECT id_alumno, nombre FROM alumnos ORDER BY nombre");
            while ($a = mysqli_fetch_assoc($alumnos)) {
                echo "<option value='{$a['id_alumno']}'>{$a['nombre']}</option>";
            }
            ?>
        </select>
        <label>Cantidad a prestar</label>
        <input type="number" name="cantidad" min="1" value="1" required>
        <button type="submit" name="prestar">📚 Confirmar Préstamo</button>
    </form>
</section>

</body>
</html>
