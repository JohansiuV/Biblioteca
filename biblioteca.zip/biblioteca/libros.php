<?php include('config/conexion.php'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Libros</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h1>📚 Inventario</h1>

<nav>
    <a href="index.php">Inicio</a>
    <a href="alumnos.php">Alumnos</a>
    <a href="prestamos.php">Préstamos</a>
</nav>

<section>
<form method="POST">
    <input type="text" name="titulo" placeholder="Título" required>
    <input type="number" name="stock" placeholder="Stock" required>
    <button name="guardar">Guardar</button>
</form>

<?php
if(isset($_POST['guardar'])){
    mysqli_query($conn, "INSERT INTO libros (titulo, stock) VALUES ('$_POST[titulo]',$_POST[stock])");
}
?>
</section>

<section>
<table>
<tr><th>ID</th><th>Título</th><th>Stock</th></tr>
<?php
$res = mysqli_query($conn, "SELECT * FROM libros");
while($l = mysqli_fetch_assoc($res)){
    $alerta = ($l['stock'] == 0) ? "class='alerta'" : "";
    echo "<tr>
            <td>{$l['id_libro']}</td>
            <td>{$l['titulo']}</td>
            <td $alerta>{$l['stock']}</td>
          </tr>";
}
?>
</table>
</section>

</body>
</html>
